function [modulus] = VectorModulus(vector)
   
    modulus = sum(vector.^2);
    
end