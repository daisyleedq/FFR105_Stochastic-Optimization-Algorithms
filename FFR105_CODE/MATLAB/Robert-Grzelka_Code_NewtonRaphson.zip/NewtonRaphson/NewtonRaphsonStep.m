function [xj] = NewtonRaphsonStep(xi,fxiPrim,fxiPPrim)
% Function NewtonRaphsonStep takes value of point on abscisa "xi", 
% its tangent (slope) value "fxiPrim" on ordinata, 
% and its  normal (curve
%
%
xj = xi - fxiPrim / fxiPPrim;

end